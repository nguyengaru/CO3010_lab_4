#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdint.h>

#define SCH_MAX_TASKS 40U
#define SCH_TICK_MS   10U
#define NO_TASK_ID    0U

#define RETURN_ERROR  0U
#define RETURN_NORMAL 1U

#define ERROR_SCH_TOO_MANY_TASKS     1U
#define ERROR_SCH_CANNOT_DELETE_TASK 2U
#define ERROR_SCH_INVALID_TASK       3U

extern uint8_t Error_code_G;

void SCH_Init(void);
void SCH_Update(void); /* Call from the 10 ms TIM2 interrupt */
void SCH_Dispatch_Tasks(void); /* Call repeatedly from while(1) */
uint32_t SCH_Add_Task(void (*pFunction)(void), uint32_t DELAY, uint32_t PERIOD);
uint8_t SCH_Delete_Task(uint32_t taskID);
uint32_t SCH_Get_Time(void); /* milliseconds */

#endif
