#include "scheduler.h"
#include "main.h" /* CMSIS interrupt control functions */

#define NIL 0xFFU

typedef enum { SLOT_FREE = 0U, SLOT_WAITING, SLOT_READY } SlotState;

typedef struct {
    void (*pTask)(void);
    uint32_t Delay;  /* delta ticks from previous task in WAITING list */
    uint32_t Period; /* 0 means one-shot */
    uint32_t TaskID;
    uint8_t next;
    uint8_t state;
} sTask;

static sTask tasks[SCH_MAX_TASKS];
static uint8_t waiting_head = NIL;
static uint8_t ready_queue[SCH_MAX_TASKS];
static uint8_t ready_head, ready_tail, ready_count;
static uint32_t next_id = 1U;
static volatile uint32_t tick_count;

uint8_t Error_code_G = 0U;

static uint32_t enter_critical(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    return primask;
}

static void exit_critical(uint32_t primask)
{
    if (primask == 0U) __enable_irq();
}

static void clear_slot(uint8_t i)
{
    tasks[i].pTask = 0;
    tasks[i].Delay = 0U;
    tasks[i].Period = 0U;
    tasks[i].TaskID = NO_TASK_ID;
    tasks[i].next = NIL;
    tasks[i].state = SLOT_FREE;
}

/* Insert into a delta-delay sorted list. Must be called with IRQs locked. */
static void waiting_insert(uint8_t idx, uint32_t delay)
{
    uint8_t prev = NIL;
    uint8_t cur = waiting_head;

    /* >= keeps insertion order for tasks with equal deadlines. */
    while ((cur != NIL) && (delay >= tasks[cur].Delay)) {
        delay -= tasks[cur].Delay;
        prev = cur;
        cur = tasks[cur].next;
    }

    tasks[idx].Delay = delay;
    tasks[idx].next = cur;
    tasks[idx].state = SLOT_WAITING;
    if (cur != NIL) tasks[cur].Delay -= delay;

    if (prev == NIL) waiting_head = idx;
    else tasks[prev].next = idx;
}

static void ready_push(uint8_t idx)
{
    /* At most SCH_MAX_TASKS slots can be READY, so this queue cannot overflow. */
    ready_queue[ready_tail] = idx;
    ready_tail = (uint8_t)((ready_tail + 1U) % SCH_MAX_TASKS);
    ready_count++;
}

void SCH_Init(void)
{
    uint8_t i;
    for (i = 0U; i < SCH_MAX_TASKS; i++) clear_slot(i);

    waiting_head = NIL;
    ready_head = 0U;
    ready_tail = 0U;
    ready_count = 0U;
    next_id = 1U;
    tick_count = 0U;
    Error_code_G = 0U;
}

/* Call once per 10 ms from HAL_TIM_PeriodElapsedCallback().
 * Work is O(1) if no task expires; O(k) if k tasks expire on this tick.
 */
void SCH_Update(void)
{
    tick_count++;
    if (waiting_head == NIL) return;

    if (tasks[waiting_head].Delay > 0U) tasks[waiting_head].Delay--;

    /* Move all tasks due on this tick to READY in deadline/insertion order. */
    while ((waiting_head != NIL) && (tasks[waiting_head].Delay == 0U)) {
        uint8_t idx = waiting_head;
        waiting_head = tasks[idx].next;
        tasks[idx].next = NIL;
        tasks[idx].state = SLOT_READY;
        ready_push(idx);
    }
}

uint32_t SCH_Add_Task(void (*pFunction)(void), uint32_t DELAY, uint32_t PERIOD)
{
    uint32_t primask;
    uint8_t i;
    uint32_t id;

    if (pFunction == 0) {
        Error_code_G = ERROR_SCH_INVALID_TASK;
        return NO_TASK_ID;
    }

    primask = enter_critical();
    for (i = 0U; i < SCH_MAX_TASKS; i++) {
        if (tasks[i].state == SLOT_FREE) break;
    }
    if (i == SCH_MAX_TASKS) {
        Error_code_G = ERROR_SCH_TOO_MANY_TASKS;
        exit_critical(primask);
        return NO_TASK_ID;
    }

    id = next_id++;
    if (next_id == NO_TASK_ID) next_id = 1U;

    tasks[i].pTask = pFunction;
    tasks[i].Period = PERIOD;
    tasks[i].TaskID = id;
    tasks[i].next = NIL;

    /* A zero initial delay means READY immediately, not after the next tick. */
    if (DELAY == 0U) {
        tasks[i].Delay = 0U;
        tasks[i].state = SLOT_READY;
        ready_push(i);
    } else {
        waiting_insert(i, DELAY);
    }

    exit_critical(primask);
    return id;
}

void SCH_Dispatch_Tasks(void)
{
    for (;;) {
        uint32_t primask = enter_critical();
        uint8_t idx;
        void (*fn)(void);
        uint32_t period;

        if (ready_count == 0U) {
            exit_critical(primask);
            break;
        }

        idx = ready_queue[ready_head];
        ready_head = (uint8_t)((ready_head + 1U) % SCH_MAX_TASKS);
        ready_count--;

        fn = tasks[idx].pTask;
        period = tasks[idx].Period;

        if (fn == 0) {
            clear_slot(idx); /* task was deleted while READY */
            exit_critical(primask);
            continue;
        }

        if (period > 0U) waiting_insert(idx, period);
        else clear_slot(idx);

        exit_critical(primask);
        fn(); /* callbacks always execute outside the timer ISR */
    }
}

uint8_t SCH_Delete_Task(uint32_t taskID)
{
    uint32_t primask;
    uint8_t i;

    if (taskID == NO_TASK_ID) {
        Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
        return RETURN_ERROR;
    }

    primask = enter_critical();
    for (i = 0U; i < SCH_MAX_TASKS; i++) {
        if ((tasks[i].state != SLOT_FREE) && (tasks[i].TaskID == taskID)) break;
    }

    if (i == SCH_MAX_TASKS) {
        Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
        exit_critical(primask);
        return RETURN_ERROR;
    }

    if (tasks[i].state == SLOT_WAITING) {
        uint8_t prev = NIL;
        uint8_t cur = waiting_head;
        uint8_t next;

        while ((cur != NIL) && (cur != i)) {
            prev = cur;
            cur = tasks[cur].next;
        }
        if (cur == NIL) { /* defensive consistency check */
            Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
            exit_critical(primask);
            return RETURN_ERROR;
        }

        next = tasks[i].next;
        if (next != NIL) tasks[next].Delay += tasks[i].Delay;
        if (prev == NIL) waiting_head = next;
        else tasks[prev].next = next;
        clear_slot(i);
    } else {
        /* READY entry remains in FIFO; dispatcher will discard it safely. */
        tasks[i].pTask = 0;
    }

    exit_critical(primask);
    return RETURN_NORMAL;
}

uint32_t SCH_Get_Time(void)
{
    return tick_count * SCH_TICK_MS;
}
